# Stickman World Short Kit V2

A vertical short-video production kit using **2D cartoon-stickman characters inside a stylized 3D cartoon environment**.

## Visual standard
Characters follow the supplied reference sheet: oversized white round heads, large expressive black eyes and eyebrows, small expressive mouths, compact coloured shirts, thin stick-like arms and legs, readable cartoon hands/gloves, simple shoes, and bold black outlines. They remain flat 2D transparent cards. The world (sets, buildings, props, vehicles, terrain and lighting) remains 3D.

## Audio and subtitles
- `tools/mix.py` mixes voiceover + music + SFX using the kit's RMS/peak rules.
- `audio.py` creates stems only (`music.wav`, `sfx.wav`).
- No subtitle generator, SRT, subtitle TXT, WebVTT, or burned-in captions are included. Add subtitles later in your editor.
- A plain narration script may be used by `timing.py` for timing only; it is not a subtitle asset.

## Quick start
```bash
bash tools/setup.sh ~/shorts/my-short
```
See `Skill.md` for the complete production workflow, shot planning, rendering, audio mixing and QA instructions.
