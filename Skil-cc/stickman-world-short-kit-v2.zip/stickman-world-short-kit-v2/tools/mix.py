#!/usr/bin/env python3
"""Mix voice + generated music/SFX stems with measurable level targets.

Usage: python3 mix.py voice.mp3 music.wav sfx.wav [--out mix_raw.wav]
Music target: -6.02 dB relative to gated voice RMS (amplitude 0.5).
SFX target: at most -6.02 dB RMS, then peak-capped to 0.70x voice peak.
No ducking, sidechain, compression, or loudness normalization is applied here.
"""
import argparse, subprocess, sys, numpy as np, wave

SR = 48000

def decode(path):
    cmd = ['ffmpeg', '-v', 'error', '-i', path, '-f', 'f32le', '-acodec', 'pcm_f32le', '-ar', str(SR), '-ac', '2', '-']
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode:
        raise RuntimeError(f"Gagal membaca {path}: {p.stderr.decode(errors='ignore')[-500:]}")
    x = np.frombuffer(p.stdout, dtype=np.float32).copy()
    if not x.size: raise ValueError(f"File audio kosong: {path}")
    return x.reshape(-1, 2)

def gated_rms(x, gate_db=-45.0):
    mono = np.mean(x, axis=1)
    block = max(1, int(SR * 0.4))
    rms = np.array([np.sqrt(np.mean(mono[i:i+block]**2) + 1e-15) for i in range(0, len(mono), block)])
    peak = float(np.max(rms)) if len(rms) else 0.0
    keep = rms > max(1e-7, peak * 10 ** (gate_db / 20))
    if not np.any(keep): return float(np.sqrt(np.mean(mono**2) + 1e-15))
    return float(np.sqrt(np.mean(rms[keep]**2)))

def fit_length(x, n):
    if len(x) >= n: return x[:n].copy()
    return np.pad(x, ((0, n-len(x)), (0, 0)))

def write_wav(path, x):
    pcm = (np.clip(x, -1, 1) * 32767).astype('<i2')
    with wave.open(path, 'wb') as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('voice'); ap.add_argument('music'); ap.add_argument('sfx')
    ap.add_argument('--out', default='mix_raw.wav')
    args = ap.parse_args()
    voice = decode(args.voice); music = fit_length(decode(args.music), len(voice)); sfx = fit_length(decode(args.sfx), len(voice))
    vr = gated_rms(voice); mr = gated_rms(music); sr = gated_rms(sfx)
    if vr <= 1e-8: raise ValueError('Voiceover terlalu senyap untuk dijadikan acuan level.')
    target = vr * 0.5
    mg = target / max(mr, 1e-9)
    sg = target / max(sr, 1e-9)
    music *= mg; sfx *= sg
    voice_peak = float(np.max(np.abs(voice)))
    sfx_peak = float(np.max(np.abs(sfx)))
    peak_cap = voice_peak * 0.70
    if sfx_peak > peak_cap > 0: sfx *= peak_cap / sfx_peak
    mix = voice + music + sfx
    # A transparent peak limiter only; no compressor or ducking.
    peak = float(np.max(np.abs(mix)))
    if peak > 0.999: mix *= 0.999 / peak
    fade = min(int(0.04 * SR), len(mix))
    if fade: mix[-fade:] *= np.linspace(1.0, 0.0, fade, dtype=np.float32)[:, None]
    write_wav(args.out, mix)
    final_mr = gated_rms(music); final_sr = gated_rms(sfx)
    db = lambda x: 20*np.log10(max(x, 1e-12)/vr)
    print(f'Voice gated RMS : {vr:.6f} (0.00 dB reference)')
    print(f'Music gated RMS : {final_mr:.6f} ({db(final_mr):.2f} dB vs voice; target -6.02 dB)')
    print(f'SFX gated RMS   : {final_sr:.6f} ({db(final_sr):.2f} dB vs voice; capped peak <= 0.70x voice peak)')
    print(f'Voice peak      : {voice_peak:.6f}; SFX peak: {float(np.max(np.abs(sfx))):.6f}')
    print(f'Output          : {args.out}; duration {len(mix)/SR:.2f}s')

if __name__ == '__main__':
    try: main()
    except Exception as e: print(f'ERROR: {e}', file=sys.stderr); sys.exit(1)
