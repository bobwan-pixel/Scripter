// 2D cartoon-stickman renderer for transparent cards inside the 3D world.
// Character language: oversized white round head, expressive black eyes/brows,
// tiny nose or none, compact coloured shirt, thin stick limbs, cartoon gloves.
// Canvas design space: 600x1000; feet remain near y=965 for the existing card API.
const STICK_INK = '#171316';
const STICK_WHITE = '#fffefa';
const STICK_PALETTE = {
  legion: '#b83232', old: '#8d929a', toga: '#e9e1d2', civA: '#347dc3',
  civB: '#d8a33b', civC: '#5b9a55', workA: '#9b6745', workB: '#477f83'
};
const stickPath = (g, pts, width, color = STICK_INK, fill = null) => {
  g.beginPath(); g.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) g.lineTo(pts[i][0], pts[i][1]);
  g.lineCap = 'round'; g.lineJoin = 'round'; g.lineWidth = width; g.strokeStyle = color;
  if (fill) { g.closePath(); g.fillStyle = fill; g.fill(); }
  g.stroke();
};
const rounded = (g, x, y, w, h, r, fill, stroke = STICK_INK, sw = 12) => {
  g.beginPath(); g.roundRect(x, y, w, h, r); g.fillStyle = fill; g.fill(); g.lineWidth = sw; g.strokeStyle = stroke; g.stroke();
};
function drawEye(g, x, y, look, scale = 1) {
  g.fillStyle = '#050505'; g.beginPath(); g.ellipse(x + look * 5, y, 17 * scale, 25 * scale, 0, 0, Math.PI * 2); g.fill();
  g.fillStyle = '#fff'; g.beginPath(); g.arc(x + look * 5 - 5, y - 9, 5 * scale, 0, Math.PI * 2); g.fill();
}
function drawFace(g, expr, look = 0, blink = false) {
  const lx = 238, rx = 362, eyeY = 258;
  if (expr === 'angry' || expr === 'stern' || expr === 'stubborn') {
    stickPath(g, [[207, 207], [250, 220]], 11); stickPath(g, [[350, 220], [393, 207]], 11);
  } else if (expr === 'sad' || expr === 'nervous') {
    stickPath(g, [[207, 220], [244, 207]], 9); stickPath(g, [[356, 207], [393, 220]], 9);
  } else {
    stickPath(g, [[208, 210], [235, 201], [258, 204]], 9);
    stickPath(g, [[342, 204], [365, 201], [392, 210]], 9);
  }
  if (blink || expr === 'sleep' || expr === 'snore') {
    stickPath(g, [[215, eyeY], [259, eyeY]], 10); stickPath(g, [[341, eyeY], [385, eyeY]], 10);
  } else {
    const s = expr === 'shock' ? 1.13 : 1;
    drawEye(g, lx, eyeY, look, s); drawEye(g, rx, eyeY, look, s);
  }
  // Nose intentionally omitted/minimal, matching the supplied character sheet.
  g.strokeStyle = STICK_INK; g.fillStyle = '#160d0d'; g.lineWidth = 10;
  g.beginPath();
  if (expr === 'shock') { g.ellipse(300, 345, 25, 37, 0, 0, Math.PI * 2); g.fill(); }
  else if (expr === 'laugh' || expr === 'grin' || expr === 'happy') {
    g.moveTo(245, 337); g.quadraticCurveTo(300, 397, 355, 337); g.quadraticCurveTo(300, 420, 245, 337); g.fill();
    g.fillStyle = '#e87970'; g.beginPath(); g.ellipse(300, 379, 25, 12, 0, 0, Math.PI); g.fill();
  } else if (expr === 'sad') {
    g.moveTo(250, 370); g.quadraticCurveTo(300, 325, 350, 370); g.stroke();
  } else if (expr === 'angry' || expr === 'stern' || expr === 'stubborn') {
    g.moveTo(260, 365); g.lineTo(340, 365); g.stroke();
  } else if (expr === 'nervous') {
    g.moveTo(270, 363); g.quadraticCurveTo(300, 345, 330, 363); g.stroke();
  } else {
    g.moveTo(245, 340); g.quadraticCurveTo(300, 390, 355, 340); g.stroke();
  }
}
function drawGlove(g, x, y, angle = 0, pose = 'open') {
  g.save(); g.translate(x, y); g.rotate(angle);
  g.fillStyle = STICK_WHITE; g.strokeStyle = STICK_INK; g.lineWidth = 9;
  // palm
  g.beginPath(); g.ellipse(0, 0, 25, 29, 0, 0, Math.PI * 2); g.fill(); g.stroke();
  if (pose === 'fist') {
    for (let i = -1; i <= 1; i++) { g.beginPath(); g.arc(i * 11, -12, 8, Math.PI, 0); g.stroke(); }
  } else if (pose === 'point') {
    stickPath(g, [[8, -10], [18, -35], [48, -48]], 10);
    stickPath(g, [[-12, -18], [-25, -28], [-31, -12]], 9);
    stickPath(g, [[-17, 0], [-29, 12], [-18, 22]], 9);
  } else {
    // Four simple cartoon fingers, separated enough to read at phone size.
    stickPath(g, [[-15, -13], [-23, -34], [-19, -43]], 9);
    stickPath(g, [[-5, -19], [-8, -43], [-2, -50]], 9);
    stickPath(g, [[7, -18], [12, -40], [19, -43]], 9);
    stickPath(g, [[17, -9], [31, -24], [38, -22]], 9);
    stickPath(g, [[-17, 8], [-29, 18], [-24, 29]], 9);
  }
  g.restore();
}
const ARM_POSES = {
  hang: [[70, 90], [86, 230]], point: [[90, 30], [185, 0]],
  up: [[55, -75], [62, -190]], wave: [[75, -45], [105, -155]],
  hip: [[100, 90], [55, 205]], belly: [[80, 125], [22, 170]],
  temple: [[75, 15], [72, -75]], lift: [[55, -70], [20, -180]],
  reach: [[105, -20], [185, -75]], cheek: [[65, 0], [70, -35]],
  thumb: [[90, 55], [130, 20]], spear: [[55, 80], [65, 155]],
  shield: [[45, 100], [25, 185]], cross: [[-50, 85], [75, 95]]
};
function drawArm(g, side, pose, shoulderY, bob) {
  const baseX = 300 + side * 105, baseY = shoulderY + bob;
  const p = ARM_POSES[pose] || ARM_POSES.hang;
  const pts = [[baseX, baseY], [baseX + side * p[0][0], baseY + p[0][1]], [baseX + side * p[1][0], baseY + p[1][1]]];
  stickPath(g, pts, 17);
  const handPose = pose === 'point' ? 'point' : (pose === 'shield' || pose === 'spear' ? 'fist' : 'open');
  drawGlove(g, pts[2][0], pts[2][1], pose === 'up' || pose === 'wave' ? -0.35 : 0, handPose);
}
function drawCap(g, style = 'backward', color = '#d83d43') {
  g.save(); g.fillStyle = color; g.strokeStyle = STICK_INK; g.lineWidth = 13;
  g.beginPath(); g.arc(300, 175, 158, Math.PI, Math.PI * 2); g.lineTo(458, 178); g.quadraticCurveTo(300, 222, 142, 178); g.closePath(); g.fill(); g.stroke();
  g.fillStyle = '#f5f4ef'; g.beginPath(); g.ellipse(300, 130, 48, 36, 0, Math.PI, Math.PI * 2); g.fill(); g.stroke();
  g.fillStyle = color; rounded(g, 252, 151, 96, 27, 10, color, STICK_INK, 8);
  if (style === 'backward') { g.beginPath(); g.moveTo(145, 174); g.quadraticCurveTo(75, 215, 30, 203); g.quadraticCurveTo(88, 190, 145, 155); g.fill(); g.stroke(); }
  g.restore();
}
function drawHair(g) {
  g.fillStyle = '#d7d4cd'; g.strokeStyle = STICK_INK; g.lineWidth = 9;
  g.beginPath(); g.arc(185, 155, 48, Math.PI, Math.PI * 1.8); g.arc(415, 155, 48, Math.PI * 1.2, Math.PI * 2); g.fill(); g.stroke();
}

/** Draw a 2D cartoon-stickman on a transparent card; opts preserve the old story API.
 * opts: expr, blink, look, facing, seed, L/R arm pose, tilt, headTilt, bob, step,
 * role/outfitKey, color, hat/capStyle, headColor, gloves, shirtShape.
 */
export const stickmanFront = (p, opts = {}) => {
  const g = p.g; const role = opts.role || opts.outfitKey || 'civA';
  const shirt = opts.color || STICK_PALETTE[role] || '#347dc3';
  const expr = opts.expr || 'neutral', look = opts.look || 0;
  const bob = (opts.bob || 0) * 1000, step = opts.step || 0;
  const L = opts.L || 'hang', R = opts.R || 'hang';
  const tilt = (opts.tilt || 0) * Math.PI / 180;
  const facing = opts.facing === -1 ? -1 : 1;
  g.save(); g.translate(300, 0); g.scale(facing, 1); g.translate(-300, 0);
  g.translate(300, 0); g.rotate(tilt); g.translate(-300, 0);

  // Legs: thin, clean stick limbs with simple flat shoes.
  const hipY = 700 + bob;
  const swing = Math.sin(step * Math.PI * 2) * (step ? 30 : 0);
  stickPath(g, [[265, hipY], [245 - swing, 825 + bob], [225 - swing, 955]], 18);
  stickPath(g, [[335, hipY], [355 + swing, 825 + bob], [375 + swing, 955]], 18);
  stickPath(g, [[225 - swing, 955], [270 - swing, 955]], 18);
  stickPath(g, [[375 + swing, 955], [420 + swing, 955]], 18);

  // Arms are thin articulated lines; white cartoon hands make gestures legible.
  drawArm(g, -1, L, 440, bob); drawArm(g, 1, R, 440, bob);

  // Compact coloured shirt with short sleeves and a softly rounded hem.
  g.fillStyle = shirt; g.strokeStyle = STICK_INK; g.lineWidth = 13;
  g.beginPath(); g.moveTo(235, 420 + bob); g.lineTo(265, 390 + bob); g.lineTo(335, 390 + bob);
  g.lineTo(365, 420 + bob); g.lineTo(390, 495 + bob); g.lineTo(355, 515 + bob);
  g.lineTo(350, 700 + bob); g.quadraticCurveTo(300, 716 + bob, 250, 700 + bob);
  g.lineTo(245, 515 + bob); g.lineTo(210, 495 + bob); g.closePath(); g.fill(); g.stroke();
  // Shirt collar and restrained sleeve seams.
  g.strokeStyle = '#173c68'; g.lineWidth = 8; g.beginPath(); g.moveTo(270, 405 + bob); g.quadraticCurveTo(300, 435 + bob, 330, 405 + bob); g.stroke();

  // Large white head: intentionally oversized, with flat 2D finish and bold ink.
  const headX = 300 + (opts.headTilt || 0) * 1.5, headY = 220 + bob;
  g.fillStyle = opts.headColor || STICK_WHITE; g.strokeStyle = STICK_INK; g.lineWidth = 15;
  g.beginPath(); g.arc(headX, headY, 166, 0, Math.PI * 2); g.fill(); g.stroke();
  g.save(); g.translate(0, bob);
  drawFace(g, expr, look, !!opts.blink);

  // Optional accessories distinguish the cast without changing the base anatomy.
  if (opts.hat || opts.cap || opts.capStyle) drawCap(g, opts.capStyle || 'backward', opts.hatColor || '#d83d43');
  else if (role === 'old') drawHair(g);
  if (opts.glasses || role === 'old') {
    g.strokeStyle = STICK_INK; g.lineWidth = 8; g.beginPath();
    g.ellipse(238, 258, 35, 39, 0, 0, Math.PI * 2); g.ellipse(362, 258, 35, 39, 0, 0, Math.PI * 2);
    g.moveTo(273, 258); g.lineTo(327, 258); g.stroke();
  }
  g.restore();
  g.restore();
};
